import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import OneHotEncoder

df = pd.read_csv('train.csv')

print(df.head())
print(df.info())

features = ['GrLivArea', 'BedroomAbvGr', 'FullBath', 'Neighborhood']
target = 'SalePrice'
df = df[features + [target]].dropna()

encoder = OneHotEncoder(drop='first', sparse_output=False)  # <-- use sparse_output
encoder_location = encoder.fit_transform(df[['Neighborhood']])

encoder_df = pd.DataFrame(encoder_location, columns=encoder.get_feature_names_out(['Neighborhood']))
df_encoded = pd.concat([df.drop(columns=['Neighborhood']), encoder_df], axis=1)

X = df_encoded.drop(columns=[target])
y = df_encoded[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = LinearRegression()
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)
print(f"Mean Squared Error: {mse}")
print(f"R² Score: {r2}")

new_house = pd.DataFrame({
    'GrLivArea': [2000],
    'BedroomAbvGr': [3],
    'FullBath': [2],
    'Neighborhood': ['CollgCr']
})

new_location_encoded = encoder.transform(new_house[['Neighborhood']])
new_location_df = pd.DataFrame(new_location_encoded, columns=encoder.get_feature_names_out(['Neighborhood']))
new_house_encoded = pd.concat([new_house.drop(columns=['Neighborhood']), new_location_df], axis=1)

predicted_price = model.predict(new_house_encoded)
print(f"Predicted House Price: ${predicted_price[0]:.2f}")

# Plot
plt.scatter(y_test, y_pred, alpha=0.7)
plt.xlabel("Actual Prices")
plt.ylabel("Predicted Prices")
plt.title("Actual vs Predicted House Prices")
plt.show()
