import numpy as np
def input_matrix(name = "Matrix"):
    rows = int(input(f"Enter number of rows for {name}: "))
    colms = int(input(f"Enter number of columns for {name}: "))
    print(f"Enter elements row by row for {name}: ")
    elements = []
    for i in range(rows):
        row = list(map(float, input(f"Row {i+1}: ").split()))
        if len(row) != colms:
            print("❌ Incorrect number of columns, try again..")
            return input_matrix(name) 
        elements.append(row)
    return np.array(elements)


def display_matrix(matrix, name="Result"):
    print(f"\n{name}:")
    print(matrix)

def menu():
    print("\n<----- Matrix Operations Tools ----->")
    print("1. Addition")
    print("2. Substraction")
    print("3. Multiplication")
    print("4. Transpose")
    print("5. Determinant")
    print("6. Exit")
    choice = int(input("Enter your choice (1-6): "))
    return choice

def main():
    while True:
        choice = menu()

        if choice in [1,2,3]:
            A = input_matrix("Matrix A")
            B = input_matrix("Matrix B")

            if choice == 1:
                if A.shape == B.shape:
                    display_matrix(A + B, "A + B")
                else:
                    print("❌ Matrices must have the same dimensions for addition.")

            elif choice == 2:
                if A.shape == B.shape:
                    display_matrix(A - B, "A - B")
                else:
                    print("❌ Matrices must have the same dimensions for addition.")

            elif choice == 3:
                if A.shape == B.shape:
                    display_matrix(np.dot(A, B), "A x B")
                else:
                    print("❌ Matrices must have the same dimensions for addition.")

            elif choice == 4:
                A = input_matrix("Matrix A")
                display_matrix(A.T, "Transport of A")

            elif choice == 5:
                A = input_matrix("Matrix A")
                if A.shape[0] == A.shape[1]:
                    display_matrix(np.linalg.det(A), "Determinant of A")
                else:
                    print("❌ Matrices must have the same dimensions for addition.")

            elif choice == 6:
                print("✅ Exiting... Thank You")
                break
            else:
                print("Invalid Choice, please check..")

if __name__ == "__main__":
    main()