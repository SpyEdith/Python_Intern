#Create 3 dictionery of 3 students
student1 = {
    "name": "John",
    "age": 20,
    "grade": "A"
}
student2 = {
    "name": "Jack",
    "age": 22,
    "grade": "B"
}
student3 = {
    "name": "Jacob",
    "age": 19,
    "grade": "A+"
}          

#store then in a list
students = [student1,student2,student3]

#print name and age of each student
for student in students:
    print("Name: ",student["name"], " | Age: ", student["age"])