import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#load CSV file
df = pd.read_csv('data.csv')
print(df.head())

#data analysis task for avg sales
average_sales = df['Sales'].mean()
print(f'Average Sales: {average_sales}')

print(df.describe())
print(df.isnull().sum())

#visualization
#Bar chart
region_sales = df.groupby('Region')['Sales'].sum()
region_sales.plot(kind='bar', color='lightgreen')
plt.title("Total Sales by Region")
plt.xlabel('Region')
plt.ylabel('Sales')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

#Scatter Plot
plt.scatter(df['Sales'], df['Profit'], color='orange')
plt.title('Sales vs Profit')
plt.xlabel('Sales')
plt.ylabel('Profit')
plt.grid(True)
plt.show()

#Heatmap
correlation = df.corr(numeric_only=True)
sns.heatmap(correlation, annot=True, cmap='coolwarm')
plt.title('Correlation Heatmap')
plt.show()

'''Insights and Observations
1] data analysis task for avg sales: lets say 27000 -give benchmark for performance..
2] Bar Chart: east region has higest sales, suggest stronger customer base there..
3] Scatter Plot Insight: A positive correlation between profit and sales..
4] Heatmap : strong correlation between sales and profit, weak or negative correlation with discount..
'''